## ******************************************************************
## ******************** To produce raw data for varying parameters **
## ******************************************************************
##save the folder "code" to a directory of your choice and change the
## setwd() statement below accordingly
setwd('~/Desktop/simulation_code/')
source('initialize.R')
##Ensure you have a folder called "storage1" before doing any of the below

##To generate data used for Figs 1, 3, S2

betas <- c(0,2.5,5,7.5,10)
alphas <- c(2,10,30,50)
sigmas <- c(2,30,50)
mu.pars <- c(0.001,0.01,1)
mus <- c(0.01)
ts <- c(1)

n.sets <- length(betas)*length(alphas)*length(sigmas)*length(mu.pars)
reps <-  1:10
pars <-
  expand.grid(ts=ts,betas=betas,alphas=alphas,sigmas=sigmas,mu.pars=mu.pars,mus=mus,reps=reps)
pars$set <- rep(1:n.sets,length(reps))
run.var.parms(file.path="storage1",name="pars",varPars=pars,fixed.number.deaths=4000)

## ******************************************************************
##To generate data used for Fig. 2
##Ensure you have a folder called "storage2" before doing any of the below
setwd('~/Desktop/simulation_code/')
rm(list=ls())
source('initialize.R')

betas <- c(5)
alphas <- c(2)
sigmas <- c(2)
mu.pars <- c(0.001,0.01,1)
ts <- c(1)
mus <- c(0.01)

n.sets <- length(betas)*length(alphas)*length(sigmas)*length(mu.pars)

reps <- 1
pars <-
  expand.grid(ts=ts,betas=betas,alphas=alphas,sigmas=sigmas,mu.pars=mu.pars,mus=mus,reps=reps)
pars$set <- rep(1:n.sets,length(reps))
run.var.parms(file.path="storage2",name="pars",varPars=pars,fixed.number.deaths=400000)

## ******************************************************************
##To generate data used for Fig. S3
##Ensure you have a folder called "storage3" before doing any of the below
setwd('~/Desktop/simulation_code/')
rm(list=ls())
source('initialize.R')
## ******************************************************************
betas <- c(0,2.5,5,7.5,10)
alphas <- c(2,10,30,50)
sigmas <- c(2,30,50)
mu.pars <- c(0.001,0.01,1)
ts <- c(1)
mus <- c(0)

n.sets <- length(betas)*length(alphas)*length(sigmas)*length(mu.pars)
reps <- 1:10
pars <-
  expand.grid(betas=betas,alphas=alphas,sigmas=sigmas,mu.pars=mu.pars,ts=ts,mus=mus,reps=reps)
pars$set <- rep(1:n.sets,length(reps))
run.var.parms(file.path="storage3",name="pars",varPars=pars,fixed.number.deaths=10000)

## ******************************************************************
##To generate data used for Fig. S4
##Ensure you have a folder called "storage4" before doing any of the below
setwd('~/Desktop/simulation_code/')
rm(list=ls())
source('initialize.R')
## ******************************************************************
betas <- c(0,2.5,5,7.5,10)
alphas <- c(2,10,30,50)
sigmas <- c(2,30,50)
mu.pars <- c(0.001,0.01,1)
mus <- c(0.01)
ts <- c(1)

n.sets <- length(betas)*length(alphas)*length(sigmas)*length(mu.pars)
reps <- 1:8
pars <-
  expand.grid(ts=ts,betas=betas,alphas=alphas,sigmas=sigmas,mu.pars=mu.pars,mus=mus,reps=reps)
pars$set <- rep(1:n.sets,length(reps))
run.var.parms(file.path="storage4",name="pars",varPars=pars,fixed.number.deaths=4000,migration.fix=TRUE)



## ******************************************************************
##To generate data used for Fig. S5
##Ensure you have a folder called "storage5" before doing any of the below
setwd('~/Desktop/simulation_code/')
rm(list=ls())
source('initializeMaternalProtection.R')
## ******************************************************************

betas <- c(0,2.5,5,7.5,10)
alphas <- c(2,10,30,50)
sigmas <- c(2,50)
mus <- c(0.01)
ts <- c(1)
mu.pars <- c(0.001,0.01,1)

n.sets <- length(betas)*length(alphas)*length(sigmas)*length(mu.pars)

reps <- 1:10

pars <-
  expand.grid(ts=ts,mus=mus,betas=betas,alphas=alphas,sigmas=sigmas,mu.pars=mu.pars,reps=reps)
pars$set <- rep(1:n.sets,length(reps))

run.var.parms(file.path="storage5",name="pars",varPars=pars,fixed.number.deaths=4000)



## ******************************************************************
## To run control simulations with fixed infection rates, as
## mentioned in Results and Discussion section
##Ensure you have a folder called "storage6" before doing any of the
## below and that tab_storage1.RData has already been produced from processOutput.R
setwd('~/Desktop/simulation_code/')
rm(list=ls())
source('initialize.R')
## ******************************************************************
betas <- c(0,2.5,5,7.5,10)
alphas <- c(2,10,30,50)
sigmas <- c(2,30,50)
mu.pars <- c(0.001,0.01,1)
mus <- c(0.01)
ts <- c(1)

n.sets <- length(betas)*length(alphas)*length(sigmas)*length(mu.pars)*length(ts)

reps <- 1:10
pars <-
  expand.grid(ts=ts,betas=betas,alphas=alphas,sigmas=sigmas,mu.pars=mu.pars,mus=mus,reps=reps)
pars$set <- rep(1:n.sets,length(reps))
run.var.parms.fix.infection.control(file.path="storage6",name="pars",varPars=pars,fixed.number.deaths=4000,file.prevalence="tab_storage1.RData")
