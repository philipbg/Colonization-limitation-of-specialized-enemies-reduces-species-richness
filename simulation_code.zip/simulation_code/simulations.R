##To run simulation fixing the number of deaths
run.sim.fixed.death <- function(prms){
  pop <- initialize.pop(prms)
  pops <- list()
  continue <- TRUE
  counter <- 0
  i <- 1
  names.counter <- prms$N + 1
  while(continue){
    if(counter<=prms$fixed.number.deaths)
      pops[[counter+1]] <- pop ##first listed population is the
    ##initial one
    if(counter>prms$fixed.number.deaths){
      continue <- FALSE
      break
    }

    next.gen <- next.gen(prms,pop,names.counter)
    pop <- next.gen$pop
    names.counter <- next.gen$names.counter
    death.occurred <- next.gen$death.occurred
    counter <- counter+as.numeric(death.occurred)
    i <- i+1
  }
  pops
}

##This function is only for running Type III simulations
run.sim.fixed.death.m <- function(prms){
  pop <- initialize.pop(prms)
  pops <- list()
  continue <- TRUE
  counter <- 0
  i <- 1
  names.counter <- prms$N + 1
  ##draw for migration
  migration.time <- FALSE
  imm.rand <- runif(1)
  if(imm.rand<prms$mu){
    migration.time <- TRUE
  }
  while(continue){
    if(counter<=prms$fixed.number.deaths)
      pops[[counter+1]] <- pop ##first listed population is the initial
    ##one
    if(counter>prms$fixed.number.deaths
       ){
      continue <- FALSE
      break
    }
    if(!migration.time){
      next.gen <- next.gen.migration(prms,pop,names.counter)
    }else{
      next.gen <- next.gen.no.migration(prms,pop,names.counter)
    }
    pop <- next.gen$pop
    names.counter <- next.gen$names.counter
    death.occurred <- next.gen$death.occurred
    if(death.occurred){
      ##only when a successful recruitment and death occur
      ##see if the next recruitment will be due to migration or not
      imm.rand <- runif(1)
      if(imm.rand<prms$mu){
        migration.time <- TRUE
      }
    }
    counter <- counter+as.numeric(death.occurred)
    i <- i+1
  }
  pops
}
