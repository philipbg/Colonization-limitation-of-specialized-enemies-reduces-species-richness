## *************************************************
## ************ Plotting  **********************
## *************************************************
setwd('~/Desktop/simulation_code/')
rm(list=ls())
source("plotting.R")
library(RColorBrewer)

##************************************************************************************************************
##For Plotting Figs 3, S3, S4, S5
fig <- function(data.path, file.name,betas,alphas,sigma.ms,mu.pars,ts,xaxis,xpanel,linecols,linetypes,plot.thing,ymax,reps=10) {
    g <- function(){

      ##load the data table
        load(data.path)
      ##take a subset with the parameters to be included
      if(any(colnames(tab)=="ts")){
        sub.tab <- tab[(tab$betas%in%betas)
                       &(tab$alphas%in%alphas)
                       &(tab$sigma.ms%in%sigma.ms)
                       &(tab$mu.pars%in%mu.pars)
                       &(tab$ts%in%ts),]
      }else{
        sub.tab <- tab[(tab$betas%in%betas)
                       &(tab$alphas%in%alphas)
                       &(tab$sigma.ms%in%sigma.ms)
                       &(tab$mu.pars%in%mu.pars),]

      }


        xaxis.vals <- unique(sub.tab[,xaxis])
        xpanel.vals <- unique(sub.tab[,xpanel])
        linecols.vals <- unique(sub.tab[,linecols])
        linetype.vals <- unique(sub.tab[,linetypes])

        greys <- brewer.pal(9,"Greys")[c(3,6)]
        cols <- c(greys[1:(length(linecols.vals)-1)],"black")
        ltys <- 1:(length(linetype.vals))

        ##specify the layout
        par(mfrow=c(1, 4), mar=c(0.9,0.5,0.25,0.8),
            oma=c(1.5, 2.25, 1, 2.8), mgp=c(-0.1,-0.1,-0.1))

        ##this function will be called for each panel. x.panel.val
        ##refers to the values taken by xpanel (e.g., alphas)
        f <- function(x.panel.val,lab,labs,axes,panel){

            ##subset for this particular panel
            sub.sub.tab <- sub.tab[sub.tab[,xpanel]==x.panel.val,]

            if(plot.thing=='end')
                ymax <- ymax
            if(plot.thing=='sample')
                ymax <- ymax
            plot(NA, xlim=c(min(sub.tab[,xaxis]),max(sub.tab[,xaxis])), ylim=c(0,ymax),
                 xlab="", ylab="", las=1,
                 xaxt="n", yaxt="n")


            for(i in 1:length(linecols.vals)){
              for(j in 1:length(linetype.vals)){

                    make.line <-
                        sub.sub.tab[sub.sub.tab[,linecols]==linecols.vals[i]&
                                    sub.sub.tab[,linetypes]==linetype.vals[j],]
                    make.line <- make.line[order(make.line$betas),]
                    if(plot.thing=="sample"){
                        data.points <-
                            make.line$mean.diversities.sample.points
                        se <-
                            make.line$sd.diversities.sample.points/sqrt(reps)
                    }
                    if(plot.thing=="end"){
                        data.points <-
                            make.line$mean.diversities.at.end
                        se <-
                            make.line$sd.diversities.at.end/sqrt(reps)
                    }

                    lines(x=xaxis.vals,y=data.points,col=cols[i],lty=ltys[j])
                    points(x=xaxis.vals,y=data.points,col=cols[i],pch=16)


                    arrows(xaxis.vals,data.points-se,xaxis.vals,data.points+se,code=0,angle=90,length=0.02,col=cols[i])

                }
            }

            usr <- par("usr")
            x0 <- max(sub.tab[,xaxis])*0.08
            y0 <- 51*0.97
            text(x=x0, y=y0, panel, cex=0.7,font=2)

            ##  add axes
            if(axes[1]==1){
                axis(1, tick=FALSE, labels= xaxis.vals, at = xaxis.vals,
                     cex.axis=0.6,lwd=0,lwd.ticks=0.4,tck=-0.05,line=0)}
            if(axes[2]==1) {
                par(mgp=c(0.1,0.1,0.1))
                axis(2,  tick=FALSE, cex.axis=0.6, las=0,line=0,lwd=0,lwd.ticks=0.4,tck = -0.05)
                par(mgp=c(-0.1,-0.1,-0.1))


            }

            lab <- bquote(alpha==.(x.panel.val))
            mtext(lab, side = 3, line=0.1, at=max(xaxis.vals)/2, cex=0.6, las=1)

        }


        for(k in 1:length( xpanel.vals)){
            if(k==1) f(xpanel.vals[k],lab="a",labs=c(1,0),axes=c(1,1),panel=letters[k])
            if(k>1) f(xpanel.vals[k],lab="a",labs=c(1,0),axes=c(1,0),panel=letters[k])
        }


        mtext(expression("The strength of frequency dependence, "~beta~" "), side = 1, line=0.2, at=0.5, cex=0.5, outer=TRUE)
        y.lab <- "Local Species Richness"
        mtext(y.lab, side = 2, line=1, at=0.5, cex=0.6, outer=TRUE)
    }

    pdf.f(g, file.name, width=6, height=3)
}


fig(data.path="tab_storage5.RData",
    file.name="figS5.pdf",betas=c(0,2.5,5,7.5,10),alphas=c(2,10,30,50),sigma.ms=c(2,50),mu.pars=c(0.001,0.01,1),ts=1,xaxis="betas",xpanel="alphas",linecols="mu.pars",linetypes="sigma.ms",plot.thing="sample",ymax=51)
fig(data.path="tab_storage3.RData",
    file.name="figS3.pdf",betas=c(0,2.5,5,7.5,10),alphas=c(2,10,30,50),sigma.ms=c(2,50),mu.pars=c(0.001,0.01,1),ts=1,xaxis="betas",xpanel="alphas",linecols="mu.pars",linetypes="sigma.ms",plot.thing="end",ymax=10)
fig(data.path="tab_storage1.RData",
    file.name="fig3.pdf",betas=c(0,2.5,5,7.5,10),alphas=c(2,10,30,50),sigma.ms=c(2,50),mu.pars=c(0.001,0.01,1),ts=1,xaxis="betas",xpanel="alphas",linecols="mu.pars",linetypes="sigma.ms",plot.thing="sample",ymax=51)
fig(data.path="tab_storage4.RData",
    file.name="figS4.pdf",betas=c(0,2.5,5,7.5,10),alphas=c(2,10,30,50),sigma.ms=c(2,50),mu.pars=c(0.001,0.01,1),ts=1,xaxis="betas",xpanel="alphas",linecols="mu.pars",linetypes="sigma.ms",plot.thing="sample",ymax=15,reps=8)


##************************************************************************************************************
##For Fig. 1

fig <- function(data.path, file.name,betas,alphas,sigma.ms,mu.pars,xaxis,xpanel,linecols,linetypes) {
    g <- function(){

        ##load the data table
        load(data.path)
        ##take a subset with the parameters to be included
        sub.tab <- tab[(tab$betas%in%betas)
                       &(tab$alphas%in%alphas)
                       &(tab$sigma.ms%in%sigma.ms)
                       &(tab$mu.pars%in%mu.pars),]

        xaxis.vals <- unique(sub.tab[,xaxis])
        xpanel.vals <- unique(sub.tab[,xpanel])
        linecols.vals <- unique(sub.tab[,linecols])
        linetype.vals <- unique(sub.tab[,linetypes])

        greys <- brewer.pal(9,"Greys")[c(3,6)]
        cols <- c(greys[1:(length(linecols.vals)-1)],"black")
        ltys <- 1:(length(linetype.vals))

        ##specify the layout
        par(mfrow=c(1, 4), mar=c(0.9,0.5,0.25,0.8),
            oma=c(1.5, 2.25, 1, 2.8), mgp=c(-0.1,-0.1,-0.1))

        ##this function will be called for each panel. x.panel.val
        ##refers to the values taken by xpanel (e.g., alphas)
        f <- function(x.panel.val,lab,labs,axes,panel){


            ##subset for this particular panel
            sub.sub.tab <- sub.tab[sub.tab[,xpanel]==x.panel.val,]

            plot(NA, xlim=c(min(sub.tab[,xaxis]),max(sub.tab[,xaxis])), ylim=c(0,1),
                 xlab="", ylab="", las=1,
                 xaxt="n", yaxt="n")


            for(i in 1:length(linecols.vals)){
                for(j in 1:length(linetype.vals)){
                    make.line <-
                        sub.sub.tab[sub.sub.tab[,linecols]==linecols.vals[i]&
                                    sub.sub.tab[,linetypes]==linetype.vals[j],]
                    make.line <- make.line[order(make.line$betas),]
                    data.points <- make.line$mean.prevalence.sample.points
                    lines(x=xaxis.vals,y=data.points,col=cols[i],lty=ltys[j])
                    points(x=xaxis.vals,y=data.points,col=cols[i],pch=16)

                    se <-
                        make.line$sd.prevalence.sample.points/sqrt(10)
                    arrows(xaxis.vals,data.points-se,xaxis.vals,data.points+se,code=0,angle=90,length=0.02,col=cols[i])

                }
            }

            usr <- par("usr")
            x0 <- max(sub.tab[,xaxis])*0.1
            y0 <- 1*0.95
            text(x=x0, y=y0, panel, cex=0.7,font=2)

            ##  add axes
            if(axes[1]==1){
                axis(1, tick=FALSE, labels= xaxis.vals, at = xaxis.vals,
                     cex.axis=0.6,lwd=0,lwd.ticks=0.4,tck=-0.05,line=0)}
            if(axes[2]==1) {
                par(mgp=c(0.1,0.1,0.1))
                axis(2,  tick=FALSE, cex.axis=0.6, las=0,line=0,lwd=0,lwd.ticks=0.4,tck = -0.05)
                par(mgp=c(-0.1,-0.1,-0.1))


            }

            lab <- bquote(alpha==.(x.panel.val))
            mtext(lab, side = 3, line=0.1, at=max(xaxis.vals)/2, cex=0.6, las=1)

        }


        for(k in 1:length( xpanel.vals)){
            if(k==1) f(xpanel.vals[k],lab="a",labs=c(1,0),axes=c(1,1),panel=letters[k])
            if(k>1) f(xpanel.vals[k],lab="a",labs=c(1,0),axes=c(1,0),panel=letters[k])
        }


        mtext(expression("The strength of frequency dependence, "~beta~" "), side = 1, line=0.2, at=0.5, cex=0.5, outer=TRUE)
        y.lab <- "Proportion of trees colonized"
        mtext(y.lab, side = 2, line=1, at=0.5, cex=0.6, outer=TRUE)
    }

    pdf.f(g, file.name, width=6, height=3)
}

fig(data.path="tab_storage1.RData",
    file.name="fig1.pdf",betas=c(0,2.5,5,7.5,10),alphas=c(2,10,30,50),sigma.ms=c(2,50),mu.pars=c(0.001,0.01,1),xaxis="betas",xpanel="alphas",linecols="mu.pars",linetypes="sigma.ms")

##************************************************************************************************************
##For Fig. S2
fig <- function(data.path, file.name,betas,alphas,sigma.ms,mu.pars,xaxis,xpanel,linecols,linetypes,plot.thing) {
    g <- function(){
      ##load the data table
      load(data.path)
        ##take a subset with the parameters to be included
        sub.tab <- tab[(tab$betas%in%betas)
                       &(tab$alphas%in%alphas)
                       &(tab$sigma.ms%in%sigma.ms)
                       &(tab$mu.pars%in%mu.pars),]

        xaxis.vals <- unique(sub.tab[,xaxis])
        xpanel.vals <- unique(sub.tab[,xpanel])
        linecols.vals <- unique(sub.tab[,linecols])
        linetype.vals <- unique(sub.tab[,linetypes])

        greys <- brewer.pal(9,"Greys")[c(3,6)]
        cols <- c(greys[1:(length(linecols.vals)-1)],"black")
        ltys <- 1:(length(linetype.vals))

        ##specify the layout
        par(mfrow=c(1, 3), mar=c(0.9,0.5,0.25,0.8),
            oma=c(1.5, 2.25, 1, 2.8), mgp=c(-0.1,-0.1,-0.1))

        ##this function will be called for each panel. x.panel.val
        ##refers to the values taken by xpanel (e.g., alphas)
        f <- function(x.panel.val,lab,labs,axes,panel){


            ##subset for this particular panel
            sub.sub.tab <- sub.tab[sub.tab[,xpanel]==x.panel.val,]
            ymax <- 600

            plot(NA, xlim=c(min(sub.tab[,xaxis]),max(sub.tab[,xaxis])), ylim=c(0,ymax),
                 xlab="", ylab="", las=1,
                 xaxt="n", yaxt="n")


            for(i in 1:length(linecols.vals)){
                for(j in 1:length(linetype.vals)){
                    make.line <-
                        sub.sub.tab[sub.sub.tab[,linecols]==linecols.vals[i]&
                                    sub.sub.tab[,linetypes]==linetype.vals[j],]
                    make.line <- make.line[order(make.line$betas),]
                    data.points <-
                        make.line$mean.migrants
                    se <-
                        make.line$sd.migrants/sqrt(10)



                    lines(x=xaxis.vals,y=data.points,col=cols[i],lty=ltys[j])
                    points(x=xaxis.vals,y=data.points,col=cols[i],pch=16)

                    arrows(xaxis.vals,data.points-se,xaxis.vals,data.points+se,code=0,angle=90,length=0.02,col=cols[i])

                }
            }

            usr <- par("usr")
            x0 <- max(sub.tab[,xaxis])*0.08
            y0 <- 900*0.97
            text(x=x0, y=y0, panel, cex=0.7,font=2)

            ##   add axes
            if(axes[1]==1){
                axis(1, tick=FALSE, labels= xaxis.vals, at = xaxis.vals,
                     cex.axis=0.6,lwd=0,lwd.ticks=0.4,tck=-0.05,line=0)}
            if(axes[2]==1) {
                par(mgp=c(0.1,0.1,0.1))
                axis(2,  tick=FALSE, cex.axis=0.6, las=0,line=0,lwd=0,lwd.ticks=0.4,tck = -0.05)
                par(mgp=c(-0.1,-0.1,-0.1))


            }

            lab <- bquote(alpha==.(x.panel.val))
            mtext(lab, side = 3, line=0.1, at=max(xaxis.vals)/2, cex=0.6, las=1)

        }

        for(k in 1:length( xpanel.vals)){
            if(k==1) f(xpanel.vals[k],lab="a",labs=c(1,0),axes=c(1,1),panel=letters[k])
            if(k>1) f(xpanel.vals[k],lab="a",labs=c(1,0),axes=c(1,0),panel=letters[k])
        }


        mtext(expression("The strength of frequency dependence, "~beta~" "), side = 1, line=0.2, at=0.5, cex=0.5, outer=TRUE)
        y.lab <- "Total number of host migrants"
        mtext(y.lab, side = 2, line=1, at=0.5, cex=0.6, outer=TRUE)
    }

    pdf.f(g, file.name, width=6, height=3)
}

fig(data.path="migration.RData",
    file.name="figS2.pdf",betas=c(0,2.5,5,7.5,10),alphas=c(2,10,50),sigma.ms=c(2,50),mu.pars=c(0.001,0.01,1),xaxis="betas",xpanel="alphas",linecols="mu.pars",linetypes="sigma.ms",plot.thing="sample")

##************************************************************************************************************
##For Fig. 2
fig <- function(data.path,file.name,focal.genotype,xlim,xlabels,maxdens){
    g <- function(){
        load(data.path)
        par(mfrow=c(1, 1), mar=c(0.9,2.9,0.25,0.4),
            oma=c(1.5, 2.25, 1, 2.8), mgp=c(-0.1,-0.1,-0.1))
        greys <- brewer.pal(9,"Greys")[c(3,6)]
        cols <- c(greys[1:5-1],"black")
        outAll <- out
        plot(outAll[[1]]$abundance.frames$fitness.per.cap[1:maxdens]/max(outAll[[1]]$abundance.frames$fitness.per.cap[1:maxdens]),type='l',
             xlab="", ylab="", las=1,
             xaxt="n", yaxt="n",xlim=xlim,ylim=c(0.45,1),col=cols[1])
        points(outAll[[1]]$abundance.frames$fitness.per.cap[1:maxdens]/max(outAll[[1]]$abundance.frames$fitness.per.cap[1:maxdens]),
             xlab="", ylab="", las=1,
             xaxt="n", yaxt="n",xlim=xlim,ylim=c(0.6,1),col=cols[1],pch=16,cex=0.5)

        axis(1, tick=FALSE, labels= xlabels, at = xlabels,
             cex.axis=0.6,lwd=0,lwd.ticks=0.4,tck=-0.05,line=0)

        mtext("Relative fitness ",side=2,
              line=-2,at=0.5,cex=0.7,outer=TRUE)

        par(mgp=c(0.1,0.1,0.1))
        axis(2,  tick=FALSE, cex.axis=0.6, las=0,line=0,lwd=0,lwd.ticks=0.4,tck = -0.05)
        par(mgp=c(-0.1,-0.1,-0.1))

        mtext("Conspecific Density", side = 1, line=0.2, at=0.6, cex=0.7,
              outer=TRUE)

        lines(x=1:maxdens,y=outAll[[2]]$abundance.frames$fitness.per.cap[1:maxdens]/max(outAll[[2]]$abundance.frames$fitness.per.cap[1:maxdens]), xlab="", ylab="", las=1,
              xaxt="n", yaxt="n",xlim=xlim,col=cols[2])
        lines(x=1:maxdens,y=outAll[[3]]$abundance.frames$fitness.per.cap[1:maxdens]/max(outAll[[3]]$abundance.frames$fitness.per.cap[1:maxdens]), xlab="", ylab="", las=1,
              xaxt="n", yaxt="n",xlim=xlim,col="black")

        points(x=1:maxdens,y=outAll[[2]]$abundance.frames$fitness.per.cap[1:maxdens]/max(outAll[[2]]$abundance.frames$fitness.per.cap[1:maxdens]), xlab="", ylab="", las=1,
              xaxt="n", yaxt="n",xlim=xlim,col=cols[2],pch=16,cex=0.5)
        points(x=1:maxdens,y=outAll[[3]]$abundance.frames$fitness.per.cap[1:maxdens]/max(outAll[[3]]$abundance.frames$fitness.per.cap[1:maxdens]), xlab="", ylab="", las=1,
              xaxt="n", yaxt="n",xlim=xlim,col="black",pch=16,cex=0.5)

    }
    pdf.f(g, file.name, width=4, height=3)
}


fig(data.path="outfitnessALL.RData",
    file.name="Fig2.pdf",xlim=c(1,15),xlabels=c(1,8,15),maxdens=15)
