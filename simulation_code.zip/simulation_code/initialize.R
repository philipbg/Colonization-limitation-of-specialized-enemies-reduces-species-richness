## ******************************************************************
## ******************** source R files ******************************
## ******************************************************************
source('simulations.R')
source('runSims.R')
source('population.R')

##A population is characterized by a set of individual trees whose
##species identity is under the heading "l1, and the parasites that
##infect them under the heading "p1". Unifected trees have parasite
##0. The x and y Cartesian coordinates of each individual are also
##given. Each individual is given a name which is unique throughout
##the course of the simulation, and each individual's parent is
##tracked also, with a 0 for individuals who began within the simulation.

initialize.pop <- function(prms){
  ## assign individuals random initial locations
  names <- 1:prms$N
  parents <- rep(0,prms$N)
  x <- runif(prms$N)*prms$x.len
  y <- runif(prms$N)*prms$y.len

  ## assign individuals random initial species identity
  id <- matrix(floor(runif(prms$N)*prms$num.species+1),
                 ncol=1)

  ## assign enemies
  parasite.probs <- prms$matching.mat[id,]

  parasite <- matrix(unlist(lapply(1:prms$N, function(x) sample(1:prms$num.species,1,prob=parasite.probs[x,]))),ncol=1)
  colnames(parasite) <- "p1"
  colnames(id) <- "l1"

  ## return population
  cbind(name=names,parent=parents,x=x, y=y, a=id,p=parasite)
}


##initialize the rules for successful enemy colonization
initialize.matching <- function(prms){
  mat <- matrix(rep(prms$bad.match,prms$num.species^2),ncol=prms$num.species,byrow=TRUE)
  diag(mat) <- rep(prms$good.match,times=prms$num.species)
  mat
}

## ******************************************************************
## ******************** basic parameter set *************************
## ******************************************************************

##Make parameter list
prms.f <- function(
                   num.species=1000, ##Total number of species in the
                   ##species pool
                   sigma.m=5, ##sigma in the manuscript
                   x.len=100, ##width of landscape
                   y.len=100, ##height of landscape
                   good.match=1, ##for determining enemy colonization compatibility
                   bad.match=0, ##for determining enemy colonization compatibility
                   mu = 0.01, ##migration of trees
                   mu.par = 0.001, ##parasite migration
                   alpha = 20,
                   beta=5,
                   t = 1, ##transmission parameter
                   fixed.number.deaths=4000,
                   infection.control=FALSE, ##TRUE if controlling for
                   ##colonizing success rate
                   fixed.infection.probability=1, ##Only used if
                   ##controlling for colonization (i.e., infection
                   ##success rate)
                   density = 0.01, ##Used to calculate population size N
                   migration.fix = FALSE ##Will only be true for Type
                   ##III simulations
                   ){
  inputs <- lapply(as.list(match.call())[-1], eval.parent)
  inputs.f <- lapply(formals(), eval)
  for(v in names(inputs.f))
    if(!(v %in% names(inputs)))
      inputs <- append(inputs, inputs.f[v])
  prms <- inputs
  prms$crit.distance <- x.len
  prms$matching.mat <- initialize.matching(prms)
  prms$N <- prms$x.len*prms$y.len*prms$density ##population size
  prms
}
