#####################
Code for Greenspoon and Wadhawan. 2020. Colonization limitation of specialized enemies reduces species richness.
#####################

#####################Simulations files
#####################initialize.R : functions for initializing parameter sets and populationinitializeMaternalProtection.R :  functions for initializing parameter sets and population for simulations with maternal protectionpopulation.R : functions applied to the population such as reproduction and mortalitypopulationMaternalProtection.R : functions applied to the population such as reproduction and mortality for simulations with maternal protectionsimulations.R : functions for simulation runningrunSims.R : higher level functions for simulation runningmain.R : code to be run to produce dataprocessOutput.R : code to analyze data to produce summary statistics for different parameters setsfigures.R : code to produce plots#####################Folders#####################storage1, storage2, storage3, storage4, storage5, storage6 : folder to contain data run from main.Rdata : folder containing summarized data (made in processOutput.R) used to make figures in the paper. It contains:
	tab_typeI.RData used to make Figs 1, 3
	tab_typeII.RData used to make Fig. S3
	tab_typeIII.RData used to make Fig. S4
	migrants.RData used to make Fig. S2
	fitness.RData used to make Fig. 2
	tab_maternal.RData used to make Fig. S5#####################Workflow
#####################1. Download the folder containing the above files and folders and change the setwd(<folder>) commands to the <folder> containing the code on your computer.
2. Run simulations from main.R to fill storage folders3. Summarize data stored in storage folders in processOutput.R4. Plot summary statistics computed in processOutput.R in figures.R