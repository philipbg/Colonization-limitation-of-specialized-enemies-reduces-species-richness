## ******************************************************************
## ******************** population functions ************************
## ******************************************************************

##enemy transmission among trees
transmission <- function(prms,pop){
  uninfected <- pop[pop[,'p1']==0,,drop=FALSE]
  infected <- pop[pop[,'p1']!=0,,drop=FALSE]
  if(nrow(uninfected)>0){
    migrant.parasite.rand <- runif(nrow(uninfected))
    migration.yes <- migrant.parasite.rand<prms$mu.par
    migrant.probs <- lapply(1:nrow(uninfected), function(x) prms$matching.mat[uninfected[x,'l1'],])


    migrants <- unlist(lapply(1:nrow(uninfected), function(x) sample(1:prms$num.species,1,prob=migrant.probs[[x]])))

    if(nrow(infected)>0){
      distances <- construct.dist.mat.uninfected(prms,infected,uninfected)
      ##weighted enemy pressure
      h.unweighted <- h.func(prms,distances$distance)
      weights <- rep(prms$bad.match,length(h.unweighted))
      weights[infected[distances[,1],'p1']==uninfected[distances[,2],'l1']]<-prms$good.match
      h.weighted <- weights*h.unweighted


      probs.at.least.one.transmission <- unlist(lapply(1:nrow(uninfected), function(x) 1-prod(1-t.func(prms,h.weighted[distances[,2]==x]))))
      probs.transmission <- t.func(prms,h.weighted)
      rand.trans <- runif(nrow(uninfected))
      transmission.bool <- rand.trans<probs.at.least.one.transmission

      non.zero <- (1:nrow(uninfected))[unlist(lapply(1:nrow(uninfected), function(x)
                                                     any(probs.transmission[distances[,2]==x]!=0)))]
      zero <- (1:nrow(uninfected))[unlist(lapply(1:nrow(uninfected), function(x)
                                                     all(probs.transmission[distances[,2]==x]==0)))]
      picked <- transmission.bool*c(unlist(lapply(non.zero, function(x)
        infected[sample(1:nrow(infected),1,
                        prob=probs.transmission[distances[,2]==x]),'p1'])),rep(0,length(zero)))[order(c(non.zero,zero))]

    }
    if(nrow(infected)==0)
      picked <- rep(0,nrow(uninfected))
    picked[migration.yes] <- migrants[migration.yes]

    uninfected[,'p1']<-picked
    pop <- rbind(infected,uninfected)
  }
  pop
}

##function for determining  enemy transmission success
t.func <- function(prms,h){
  h/(prms$t+h)
}

##death of one tree
mortality <- function(prms,pop){
  probs <- rexp(nrow(pop))
  dead <- which(probs==min(probs))
  pop <- pop[-dead,]
  pop
}

##Tree reproduction
reproduction  <- function(prms,pop,names.counter){
  imm.rand <- runif(1)
  if(imm.rand<prms$mu){
    ##if immigration from outside study area
    id <- sample(1:prms$num.species,1,prob=rep(1,prms$num.species))
    new.x <- runif(1)*prms$x.len
    new.y <- runif(1)*prms$y.len
    parent <- -1
    distance <- prms$x.len
  }else{
    ##if new seed from within study area
    ##first pick reproducing tree
    chosen <- sample(1:prms$N,1)
    ##where does its new offspring disperse to
      distance <- dispersal.distance(1,prms)
      direction <- runif(1) * 2*pi
      ##torus here with the modular arithmetic

      new.x <- (pop[chosen,'x'] + cos(direction) * distance)%%prms$x.len
      new.y <- (pop[chosen,'y'] + sin(direction) *
                distance)%%prms$y.len

      id <- pop[chosen,'l1']
      parent <- pop[chosen,'name']


  }
  ##now figure out the young's probability of surviving at its new
  ##site based on the parasites around

  ##The enemy pressure for the new tree is
  ##the distances for all trees to the focal new tree
  distances <- construct.dist.mat.focal(prms,pop,new.x,new.y)
  ##weighted enemy pressure
  h.unweighted <- h.func(prms,distances$distance)
  weights <- rep(prms$bad.match,prms$N)
  weights[pop[,'p1']==id] <- prms$good.match
    h.weighted.sum <- sum(weights*h.unweighted)
  ##probability of the focal offspring surviving
  prob.survive <- p.func(prms,h.weighted.sum)
  rand <- runif(1)
  death.occurred <- FALSE
  ##if a recruitment happens
  if(rand<prob.survive){
    death.occurred <- TRUE

    pop <- mortality(prms,pop)
    if(prms$infection.control==FALSE){
      ##begins life uninfected
      pop <- rbind(pop,c(names.counter,parent,new.x,new.y,id,0))

    }
    ##for controlling for transmission dynamics
    if(prms$infection.control==TRUE){
      rand.infect <- runif(1)
      if(rand.infect<=prms$fixed.infection.probability){
        pop <- rbind(pop,c(names.counter,parent,new.x,new.y,id,id))
      }else{
        pop <- rbind(pop,c(names.counter,parent,new.x,new.y,id,0))
      }
    }
    names.counter <- names.counter +1


    if((prms$infection.control==FALSE)) {
      pop <- transmission(prms,pop)
    }

    return(list(pop=pop,death.occurred=death.occurred,names.counter=names.counter))
  }else{
    return(list(pop=pop,death.occurred=death.occurred,names.counter=names.counter))
  }

}

##Function for determining survival probability of new offspring
p.func <- function(prms,h){
  1/(1+(prms$beta*prms$N)*h)
}

##Function for determining enemy pressure
h.func <- function(prms,dist){
  (1/(2*pi*prms$alpha^2))*exp(-dist/prms$alpha)
}

##function for determining dispersal distance of offspring tree
dispersal.distance <- function(draw,prms){
  rexp(draw,1/prms$sigma.m)
}

##distance to uninfected individuals
## vector-based wrap-around distance function
dist.wa.uninfected <- function(prms,pop,uninfected){
  f <- function(i, j) {
    dx <- abs(pop[i,1] - uninfected[j,1])
    dy <- abs(pop[i,2] - uninfected[j,2])
    gtr.x <- dx>prms$x.len/2
    gtr.y <- dy>prms$y.len/2
    dx[gtr.x] <- (prms$x.len-dx)[gtr.x]
    dy[gtr.y] <- (prms$y.len-dy)[gtr.y]
    out <- sqrt(dx^2 + dy^2)
  }
  rows <- nrow(pop)
  rows.uninfected <- nrow(uninfected)

  j <- rep(1:rows.uninfected,rows)
  i <- rep.int(1:rows,rep(rows.uninfected,times=rows))
  data.frame(i=i, j=j, distance=f(i,j))
}

##distance to a focal individual
## vector-based wrap-around distance function
dist.wa.focal <- function(prms,pop,x,y){
  f <- function(j,x,y) {
    dx <- abs(x - pop[j,1])
    dy <- abs(y - pop[j,2])
    gtr.x <- dx>prms$x.len/2
    gtr.y <- dy>prms$y.len/2
    dx[gtr.x] <- (prms$x.len-dx)[gtr.x]
    dy[gtr.y] <- (prms$y.len-dy)[gtr.y]
    out <- sqrt(dx^2 + dy^2)
  }
  rows <- nrow(pop)

  j <- 1:rows
  data.frame(j=j, distance=f(j,x,y))
}


## compute pair-wise distances
construct.dist.mat.uninfected <- function(prms, pop,uninfected) {
  dists <- dist.wa.uninfected(prms,pop[,c('x','y'),drop=FALSE],uninfected[,c('x','y'),drop=FALSE])
  names(dists) <- c('i', 'j', 'distance')
  keep <- which(dists[,'distance']<prms$crit.distance)
  dists[keep,]
}

## compute pair-wise distances
construct.dist.mat.focal <- function(prms, pop,x,y) {
  dists <- dist.wa.focal(prms,pop[,c('x','y')],x,y)
  names(dists) <- c('j', 'distance')
  keep <- which(dists[,'distance']<prms$crit.distance)
  dists[keep,]
}

##To compute the next generation
next.gen <- function(prms, pop,names.counter) {
  pop.store <- reproduction(prms=prms,pop=pop,names.counter=names.counter)
  names.counter <- pop.store$names.counter
  pop <- pop.store$pop
  return(list(pop=pop,death.occurred=pop.store$death.occurred,names.counter=names.counter))
}

##The next to functions are ONLY used in type III simulations

survival <- function(prms,pop,names.counter,id,new.x,new.y,parent){
  ##figure out the young's probability of surviving at its new
  ##site based on the enemies around

  ##the distances for all trees to the focal new tree
  distances <- construct.dist.mat.focal(prms,pop,new.x,new.y)
  ##weighted enemy pressure
  h.unweighted <- h.func(prms,distances$distance)
  weights <- rep(prms$bad.match,prms$N)
  weights[pop[,'p1']==id] <- prms$good.match
  h.weighted.sum <- sum(weights*h.unweighted)
  ##probability of the focal offspring surviving
  prob.survive <- p.func(prms,h.weighted.sum)
  rand <- runif(1)
  death.occurred <- FALSE
  ##if a recruitment happens
  if(rand<prob.survive){
    death.occurred <- TRUE
    pop <- mortality(prms,pop)
    pop <- rbind(pop,c(names.counter,parent,new.x,new.y,id,0))

    names.counter <- names.counter +1

    pop <- transmission(prms,pop)

    return(list(pop=pop,death.occurred=death.occurred,names.counter=names.counter))
  }else{
    return(list(pop=pop,death.occurred=FALSE,names.counter=names.counter))
  }
}

reproduction.migration <- function(prms,pop,names.counter){
  id <- sample(1:prms$num.species,1,prob=rep(1,prms$num.species))
  new.x <- runif(1)*prms$x.len
  new.y <- runif(1)*prms$y.len
  ##for individuals in the original population parent = 0
  ##for immigrant trees, parent = -1
  ##for everyone else parent = the name of your parent
  parent <- -1
  return(survival(prms=prms,pop=pop,names.counter=names.counter,id=id,new.x=new.x,new.y=new.y,parent=parent))
}

reproduction.no.migration <- function(prms,pop,names.counter){
  ##first pick reproducing tree
  chosen <- sample(1:prms$N,1)
  ##where does its new offspring disperse to

  distance <- dispersal.distance(1,prms)
  direction <- runif(1) * 2*pi
  ##torus here with the modular arithmetic

  new.x <- (pop[chosen,'x'] + cos(direction) * distance)%%prms$x.len
  new.y <- (pop[chosen,'y'] + sin(direction) *
            distance)%%prms$y.len

  id <- pop[chosen,'l1']
  parent <- pop[chosen,'name']

  return(survival(prms=prms,pop=pop,names.counter=names.counter,id=id,new.x=new.x,new.y=new.y,parent=parent))
}

next.gen.migration <- function(prms, pop,names.counter){
  pop.store <- reproduction.migration(prms=prms,pop=pop,names.counter=names.counter)
  names.counter <- pop.store$names.counter
  pop <- pop.store$pop
  return(list(pop=pop,death.occurred=pop.store$death.occurred,names.counter=names.counter))
}

next.gen.no.migration <- function(prms, pop,names.counter){
  pop.store <-
    reproduction.no.migration(prms=prms,pop=pop,names.counter=names.counter)
  names.counter <- pop.store$names.counter
  pop <- pop.store$pop
  return(list(pop=pop,death.occurred=pop.store$death.occurred,names.counter=names.counter))
}
