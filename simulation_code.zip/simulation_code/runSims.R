##To run simulations with a parameter space defined in varPars
run.var.parms <- function(file.path,name,varPars,fixed.number.deaths,migration.fix=FALSE){
  for(j in 1:nrow(varPars)){
    print(j)
    row <- varPars[j,]
    rep=row$rep
    set=row$set

    t <- row$ts
    beta <- row$betas
    alpha <- row$alphas
    sigma.m <- row$sigmas
    mu.par <- row$mu.pars
    mu <- row$mus
    fixed.number.deaths <- fixed.number.deaths
    migration.fix = migration.fix
    prms <- prms.f(beta=beta,
                   alpha=alpha,
                   sigma.m =sigma.m,
                   t=t,
                   mu.par = mu.par,
                   mu = mu,
                   fixed.number.deaths=fixed.number.deaths,
                   migration.fix = migration.fix
                   )
    file.name <-
      sprintf("%s_mu_%f_t_%.1f_beta_%.1f_alpha_%d_sigmaM_%d_muPar_%f_set_%d_rep_%d.RData",name,prms$mu,prms$t,prms$beta,prms$alpha,prms$sigma.m,prms$mu.par,set,rep)

    if(nchar(file.path)>0)
      file.name <- file.path(file.path,file.name)
    if(!file.exists(file.name)){
      if(!prms$migration.fix)
        data <- run.sim.fixed.death(prms)
      ##Only for generating Type III simulations
      if(prms$migration.fix)
        data <- run.sim.fixed.death.m(prms)
      data.prms <- list(data=data,prms=prms)

      save(data.prms,file=file.name)
    }

  }
}

##Used for control simulations with fixed infection rates, as
##mentioned in Results and Discussion section
run.var.parms.fix.infection.control <- function(file.path,name,prms,varPars,fixed.number.deaths,file.prevalence){
  for(j in 1:nrow(varPars)){
    print(j)
    load(file.prevalence)
    row <- varPars[j,]
    fixed.infection.probability <- tab[tab$betas==row$betas&tab$alphas==row$alphas&tab$sigma.ms==row$sigma&tab$mu.pars==row$mu.pars,]$mean.prevalence.sample.points
    rep=row$rep
    set=row$set

    t <- row$ts
    beta <- row$betas
    alpha <- row$alphas
    sigma.m <- row$sigmas
    mu.par <- row$mu.pars
    fixed.number.deaths <- fixed.number.deaths

    prms <- prms.f(beta=beta,
                   alpha=alpha,
                   sigma.m =sigma.m,
                   t=t,
                   mu.par = mu.par,
                   fixed.number.deaths=fixed.number.deaths,
                   fixed.infection.probability =  fixed.infection.probability,
                   infection.control = TRUE
                   )

    file.name <-
      sprintf("%s_t_%.1f_beta_%.1f_alpha_%d_sigmaM_%d_muPar_%f_set_%d_rep_%d.RData",name,prms$t,prms$beta,prms$alpha,prms$sigma.m,prms$mu.par,set,rep)
    if(nchar(file.path)>0)
      file.name <- file.path(file.path,file.name)
    if(!file.exists(file.name)){
      data <- run.sim.fixed.death(prms)
      data.prms <- list(data=data,prms=prms)
      save(data.prms,file=file.name)
    }
  }
}

