## *************** nice little pdf function ****************
pdf.f <- function(f, file, ...) {
  cat(sprintf("Writing %s\n", file))
  pdf(file, ...)
  on.exit(dev.off())
  f()
}

## *************** nice little pdf function ****************
ps.f <- function(f, file, ...) {
  cat(sprintf("Writing %s\n", file))
  postscript(file, ...)
  on.exit(dev.off())
  f()
}
