setwd('~/Desktop/simulation_code/')
rm(list=ls())
source('initialize.R')

##Functions used to generate data for figure 1 and 3. Files must be produced in
##main.R first
diversities <- function(file.path){
  files <- list.files(file.path)
  diversity.sample.points <- rep(-1,length(files))
  diversity.at.end <- rep(-1,length(files))
  prevalence.sample.points.vec <- diversity.sample.points
  mu.pars <- diversity.sample.points
  sigma.ms <- diversity.sample.points
  betas <- diversity.sample.points
  alphas <- diversity.sample.points
  ts <- diversity.sample.points
  reps <- diversity.sample.points
  sets <- diversity.sample.points
  for(i in 1:length(files)){
    print(i)
    load(file.path(file.path, files[i]))
    rep <-
      as.numeric(rev(unlist(strsplit(unlist(strsplit(files[i],".RData")),"_")))[1])
    set <-
      as.numeric(rev(unlist(strsplit(unlist(strsplit(files[i],".RData")),"_")))[3])
    diversity.at.end[i] <-
      length(unique(data.prms$data[[length(data.prms$data)]][,'l1']))
    time2000 <- length(unique(data.prms$data[[2000+1]][,'l1']))
    time3000 <- length(unique(data.prms$data[[3000+1]][,'l1']))
    time4000 <- length(unique(data.prms$data[[4000+1]][,'l1']))

    diversity.sample.points[i] <- mean(c(time2000,time3000,time4000),na.rm=TRUE)
    prevalence <- function(set){
      prevalence <- length(which(set>0))/length(set)
      prevalence
    }
    prevalence.sample.points.vec[i] <- mean(unlist(lapply(1:length(data.prms$data),function(t)
      prevalence(data.prms$data[[t]][,'p1'])))[c(2001,3001,4001)])
    mu.pars[i] <- data.prms$prms$mu.par
    sigma.ms[i] <- data.prms$prms$sigma.m

    ##
    split.string <- unlist(strsplit(files[i],split="_"))
    beta.to.take <- as.numeric(split.string[(which(split.string=="beta")+1)])
  ##


    betas[i] <- beta.to.take
    alphas[i] <- data.prms$prms$alpha
    ts[i] <- data.prms$prms$t
    reps[i] <- rep
    sets[i] <- set
  }
  all <- data.frame(sets=sets,betas=betas,alphas=alphas,ts=ts,sigma.ms=sigma.ms,mu.pars=mu.pars,reps=reps,diversity.sample.points=diversity.sample.points,diversity.at.end=diversity.at.end,prevalence.sample.points.vec)
  all
}
produce.summary.table <- function(file.path){
  out <- diversities(file.path)
  sets <- 1:length(unique(out$sets))
  mean.diversities.sample.points <- rep(-1,length(sets))
  mean.diversities.at.end <- mean.diversities.sample.points
  mean.prevalence.sample.points <- mean.diversities.sample.points
  sd.diversities.sample.points <- mean.diversities.sample.points
  sd.diversities.at.end <- mean.diversities.sample.points
  sd.prevalences.sample.points <- mean.diversities.sample.points


  ##look across all reps of a particular set and take the average
  for(i in sets){
    mean.diversities.sample.points[i] <-
      mean(out[out$sets==i,]$diversity.sample.points)
    mean.diversities.at.end[i] <- mean(out[out$sets==i,]$diversity.at.end)
    sd.diversities.sample.points[i] <-
      sd(out[out$sets==i,]$diversity.sample.points)
    sd.diversities.at.end[i] <- sd(out[out$sets==i,]$diversity.at.end)
    mean.prevalence.sample.points[i] <-
      mean(out[out$sets==i,]$prevalence.sample.points)
    sd.prevalences.sample.points[i] <- sd(out[out$sets==i,]$prevalence.sample.points)
  }
  ##put those averages in a table
  tab <- out[out$reps==1,]
  tab <- tab[order(tab$sets),]
  tab$mean.diversities.sample.points <- mean.diversities.sample.points
  tab$mean.diversities.at.end <- mean.diversities.at.end
  tab$sd.diversities.sample.points <- sd.diversities.sample.points
  tab$sd.diversities.at.end <- sd.diversities.at.end
  tab$mean.prevalence.sample.points <- mean.prevalence.sample.points
  tab$sd.prevalence.sample.points <- sd.prevalences.sample.points
  tab<-tab[,-c(which(names(tab)=="reps"),which(names(tab)=="diversity.sample.points"),which(names(tab)=="diversity.at.end"),which(names(tab)=="prevalence.sample.points.vec"))]
  file.name <- paste("tab_",file.path,".RData",sep="")
  save(tab,file=file.name)
}
produce.summary.table("storage1")
produce.summary.table("storage2")
produce.summary.table("storage3")
produce.summary.table("storage4")
produce.summary.table("storage5")
produce.summary.table("storage6")



##Used to generate data for figure S2. Files must be produced in
##main.R first
effective.immigration.rate <- function(file.path){

    files <- list.files(file.path)
    migrants.vec <- rep(-1,length(files))

    mu.pars <-  migrants.vec
    sigma.ms <-  migrants.vec
    betas <-  migrants.vec
    alphas <-  migrants.vec
    reps <-  migrants.vec
    sets <-  migrants.vec

    for(i in 1:length(files)){
        print(i)
        load(file.path(file.path, files[i]))
        rep <-
            as.numeric(rev(unlist(strsplit(unlist(strsplit(files[i],".RData")),"_")))[1])
        set <-
            as.numeric(rev(unlist(strsplit(unlist(strsplit(files[i],".RData")),"_")))[3])
        total.time <- length(data.prms$data)

        mu.pars[i] <- data.prms$prms$mu.par
        sigma.ms[i] <- data.prms$prms$sigma.m
        betas[i] <- data.prms$prms$beta
        alphas[i] <- data.prms$prms$alpha
        reps[i] <- rep
        sets[i] <- set

        death.times <- 2:length(data.prms$data)
        parent <- rep(-2,length(death.times))
        for(j in 1:length(death.times)){
            landscape <- data.prms$data[[death.times[j]]]
            pop.size <- nrow(landscape)
            parent[j] <- landscape[pop.size,'parent']
        }
        migrants <- length(which(parent==-1))
        migrants.vec[i] <- migrants
    }
    all <- data.frame(sets=sets,betas=betas,alphas=alphas,sigma.ms=sigma.ms,mu.pars=mu.pars,reps=reps,migrants.vec=migrants.vec)
    all
}

out <-
    effective.immigration.rate("storage1")

sets <- 1:length(unique(out$sets))
mean.migrants <- rep(-1,length(sets))
sd.migrants <- mean.migrants

##look across all reps of a particular set and take the average
for(i in sets){
    mean.migrants[i] <- mean(out[out$sets==i,]$migrants.vec)
    sd.migrants[i] <- sd(out[out$sets==i,]$migrants.vec)
}

##put those averages in a table
tab <- out[out$reps==1,]
tab <- tab[order(tab$sets),]
tab$mean.migrants <- mean.migrants
tab$sd.migrants <- sd.migrants

save(tab,file="migration.RData")


####*********************************
##Used to process data to generate Fig. 2, which shows fitnesses
##through time
fitness.through.time <-function(file.path,betas,alphas,sigmas,mu.pars){
  files <- list.files(file.path)
  subset.files <- function(file.path,betas,alphas,sigmas,mu.pars){
    files <- list.files(file.path)
    files.subset <- list()
    j <- 1
    for(i in 1:length(files)){
        file <- files[i]
        split.name <- strsplit(file,split="_")[[1]]
        beta.file <- as.numeric(split.name[which(split.name=='beta')+1])
        alpha.file <- as.numeric(split.name[which(split.name=='alpha')+1])
        sigma.file <- as.numeric(split.name[which(split.name=='sigmaM')+1])
        mupar.file <- as.numeric(split.name[which(split.name=='muPar')+1])
        if(beta.file%in%betas&
           alpha.file%in%alphas&
           sigma.file%in%sigmas&
           mupar.file%in%mu.pars){
            files.subset[[j]] <- file
            j <- j+1
        }

    }
    files.subset
  }
  files <- unlist(subset.files(file.path,betas=betas,alphas=alphas,sigmas=sigmas,mu.pars=mu.pars))
  migrants.vec <- rep(-1,length(files))

  mu.pars <-  migrants.vec
  sigma.ms <-  migrants.vec
  betas <-  migrants.vec
  alphas <-  migrants.vec
  reps <-  migrants.vec
  sets <-  migrants.vec

  abundance.frames <- list()
  all <- list()

  for(i in 1:length(files)){
    print(i)
    rm(data.prms)
    load(file.path(file.path, files[i]))
    rep <-
      as.numeric(rev(unlist(strsplit(unlist(strsplit(files[i],".RData")),"_")))[1])
    set <-
      as.numeric(rev(unlist(strsplit(unlist(strsplit(files[i],".RData")),"_")))[3])
    total.time <- length(data.prms$data)

    mu.pars[i] <- data.prms$prms$mu.par
    sigma.ms[i] <- data.prms$prms$sigma.m
    betas[i] <- data.prms$prms$beta
    alphas[i] <- data.prms$prms$alpha
    reps[i] <- rep
    sets[i] <- set
    death.times <- 2:length(data.prms$data)

    parent <- rep(-2,length(death.times))
    abundances.species.previous.time.step <-
      rep(-2,length(death.times))

    abundance.distribution <- table(data.prms$data[[1]][,'l1'])

    for(j in 1:length(death.times)){
      print(j)
      landscape <- data.prms$data[[death.times[j]]]
      abundance.distribution <- append(abundance.distribution,table(landscape[,'l1']))
      pop.size <- nrow(landscape)
      parent[j] <- landscape[pop.size,'parent']
      species.parent <- landscape[pop.size,'l1']
      landscape.previous.time.step <-
        data.prms$data[[death.times[j]-1]]
      abundance.parent.species.previous.time.step <-
        length(which(landscape.previous.time.step[,'l1']==species.parent))
      abundances.species.previous.time.step[j] <-  abundance.parent.species.previous.time.step
    }
    abundance.distribution.freqs <- table(factor(abundance.distribution,levels=1:pop.size))

    abundances.species.previous.time.step <- abundances.species.previous.time.step[order(abundances.species.previous.time.step)]

    abundance.frame <-
      data.frame(table(factor(abundances.species.previous.time.step,levels=1:pop.size)))


    abundance.frame$fitness.per.cap <- abundance.frame$Freq/(as.numeric(data.frame(abundance.distribution.freqs)[,1])*as.numeric(data.frame(abundance.distribution.freqs)[,2]))
    abundance.frames[[i]] <- abundance.frame

    to.save <- list(pars=data.frame(sets=sets[i],betas=betas[i],alphas=alphas[i],sigma.ms=sigma.ms[i],mu.pars=mu.pars[i],reps=reps[i]),abundance.frames=abundance.frame)
    save(to.save,file=sprintf("outFitness%d.RData",i))
  }
}
fitness.through.time("storage2",betas=c(5),alphas=2,sigmas=2,mu.pars=c(0.001,0.01,1))
out <- list()
for(i in 1:3){
  load(sprintf("outFitness%d.RData",i))
  out[[i]] <- to.save
}

save(out,file="outfitnessALL.RData")




